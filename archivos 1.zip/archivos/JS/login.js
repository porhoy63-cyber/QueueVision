// Rutas de cada dashboard. Cambia los nombres por los de tus archivos.
const destinos = {
    cliente: "/HTML/dashboard-cliente.html",
    vendedor: "/HTML/dashboard-vendedor.html",
    administrador: "/HTML/dashboard-admin.html"
};

const formLogin = document.getElementById("formLogin");

formLogin.addEventListener("submit", function (event) {

    event.preventDefault();

    const documento =
        document.getElementById("documento").value.trim();

    const password =
        document.getElementById("password").value;

    const rol =
        document.querySelector('input[name="rol"]:checked').value;


    // ---------- DOCUMENTO ----------

    if (documento === "") {

        alert("Ingresa tu número de documento.");

        return;
    }

    if (!/^[0-9]+$/.test(documento)) {

        alert("El documento solo debe contener números, sin espacios, puntos ni letras.");

        return;
    }

    if (documento.length < 6 || documento.length > 12) {

        alert("El documento debe tener entre 6 y 12 dígitos.");

        return;
    }


    // ---------- CONTRASEÑA ----------

    if (password === "") {

        alert("Ingresa tu contraseña.");

        return;
    }

    const faltantes = [];

    if (password.length < 8 || password.length > 64) {
        faltantes.push("- Entre 8 y 64 caracteres");
    }

    if (/\s/.test(password)) {
        faltantes.push("- Sin espacios");
    }

    if (!/[a-z]/.test(password)) {
        faltantes.push("- Al menos una letra minúscula");
    }

    if (!/[A-Z]/.test(password)) {
        faltantes.push("- Al menos una letra mayúscula");
    }

    if (!/[0-9]/.test(password)) {
        faltantes.push("- Al menos un número");
    }

    if (!/[^A-Za-z0-9\s]/.test(password)) {
        faltantes.push("- Al menos un carácter especial (por ejemplo: ! @ # $ % & *)");
    }

    if (password.includes(documento)) {
        faltantes.push("- No puede contener tu número de documento");
    }

    if (faltantes.length > 0) {

        alert("La contraseña no cumple con:\n\n" + faltantes.join("\n"));

        return;
    }


    // ---------- TODO CORRECTO ----------

    window.location.href = destinos[rol];

});


function mostrarPassword() {

    const password =
        document.getElementById("password");

    const icono =
        document.querySelector(".mostrar-password i");


    if (password.type === "password") {

        password.type = "text";

        icono.classList.remove("fa-eye");
        icono.classList.add("fa-eye-slash");

    } else {

        password.type = "password";

        icono.classList.remove("fa-eye-slash");
        icono.classList.add("fa-eye");

    }

}