/* QUEUEVISION - PANEL DEL LOCAL / FRANQUICIA */

/* =====================================================
   DATOS DE EJEMPLO (luego pueden venir de tu API)
===================================================== */

const franquicia = {
    nombre: "Éxito",
    tipo: "Almacén de cadena",
    descripcion: "Supermercado con mercado fresco, panadería, carnes, aseo del hogar y tecnología. Cuenta con cajas rápidas y autopago.",
    horario: "08:00 - 21:00",
    telefono: "601 555 0123",
    destacados: ["Mercado fresco", "Panadería", "Ofertas de la semana"],
    servicios: ["cajas", "autopago", "parqueadero", "domicilios", "panaderia", "tarjeta"]
};

const catalogoServicios = [
    ["cajas", "fa-cash-register", "Cajas rápidas"],
    ["autopago", "fa-mobile-screen", "Autopago"],
    ["parqueadero", "fa-square-parking", "Parqueadero"],
    ["domicilios", "fa-truck", "Domicilios"],
    ["panaderia", "fa-bread-slice", "Panadería"],
    ["tarjeta", "fa-credit-card", "Pago con tarjeta"],
    ["wifi", "fa-wifi", "WiFi gratis"],
    ["accesible", "fa-wheelchair", "Acceso para silla de ruedas"]
];

const nombresClientes = ["Camila R.", "Andrés M.", "Valentina P.", "Santiago L.", "Daniela C.", "Mateo G.", "Isabela T.", "Sebastián V.", "Laura F.", "Nicolás H."];
const prefijos = "ABCDEFGHJK";

/* Perfiles de ejemplo para las gráficas (8:00 a 19:00) */
const perfilHoras = [4, 7, 9, 12, 16, 18, 11, 8, 9, 12, 15, 13];
const esperaHoras = [3, 4, 6, 9, 14, 17, 11, 7, 8, 10, 14, 12];
const semanaBase = [310, 280, 330, 360, 480, 590, 430];
const dias = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
const horas = ["8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19"];

const config = { moderado: 35, lleno: 70, notifLlegadas: true, simulacion: true };
const textoNivel = { lleno: "Lleno", moderado: "Moderado", vacio: "Vacío" };

let siguienteIdSede = 1;
let sedes = [];
let sedeId = 1;

function nuevoTicket(sede, origen, nombre, minutosAtras) {
    sede.contador++;
    return {
        turno: sede.prefijo + "-" + String(sede.contador).padStart(3, "0"),
        nombre: nombre || nombresClientes[Math.floor(Math.random() * nombresClientes.length)],
        origen: origen,
        llegada: Date.now() - (minutosAtras || 0) * 60000
    };
}

function crearSede(datos, filaInicial) {
    const sede = Object.assign({
        id: siguienteIdSede, prefijo: prefijos[(siguienteIdSede - 1) % prefijos.length],
        contador: 0, fila: [], llamado: null, llamadas: 0, atendidos: 0, noShow: 0, abierta: true, avisos: []
    }, datos);
    siguienteIdSede++;
    for (let i = 0; i < filaInicial; i++) {
        sede.fila.push(nuevoTicket(sede, Math.random() < 0.7 ? "App" : "Presencial", null, (filaInicial - i) * 1.5));
    }
    return sede;
}

sedes = [
    crearSede({ nombre: "Éxito Av. 68", direccion: "Avenida 68 #24-10", capacidad: 23, minutos: 3.3, cajas: 3, atendidos: 142, noShow: 6 }, 18),
    crearSede({ nombre: "Éxito Calle 80", direccion: "Calle 80 #69-50", capacidad: 20, minutos: 2.5, cajas: 4, atendidos: 96, noShow: 3 }, 5),
    crearSede({ nombre: "Éxito Unicentro", direccion: "Carrera 15 #124-30", capacidad: 30, minutos: 3, cajas: 4, atendidos: 118, noShow: 5 }, 14),
    crearSede({ nombre: "Éxito Chapinero", direccion: "Carrera 13 #58-20", capacidad: 18, minutos: 3, cajas: 2, abierta: false }, 0)
];

/* =====================================================
   UTILIDADES
===================================================== */

const $ = function (selector) { return document.querySelector(selector); };

function esc(texto) {
    const d = document.createElement("div");
    d.textContent = texto;
    return d.innerHTML;
}

function sedeActual() {
    return sedes.find(function (s) { return s.id === sedeId; }) || sedes[0];
}

function calcular(s) {
    const pct = Math.min(100, Math.round((s.fila.length / s.capacidad) * 100));
    const espera = s.abierta && s.cajas > 0 ? Math.round((s.fila.length * s.minutos) / s.cajas) : 0;
    let nivel = "vacio";
    if (pct >= config.lleno) nivel = "lleno";
    else if (pct >= config.moderado) nivel = "moderado";
    return { pct: pct, espera: espera, nivel: nivel };
}

function badgeSede(s) {
    if (!s.abierta) return '<span class="badge inactivo">Cerrada</span>';
    const n = calcular(s).nivel;
    return '<span class="badge ' + n + '"><i class="fa-solid fa-circle"></i> ' + textoNivel[n] + '</span>';
}

function minutosDesde(marca) {
    return Math.max(0, Math.round((Date.now() - marca) / 60000));
}

let temporizadorToast;
function mostrarToast(mensaje) {
    const toast = $("#toast");
    toast.textContent = mensaje;
    toast.classList.add("visible");
    clearTimeout(temporizadorToast);
    temporizadorToast = setTimeout(function () { toast.classList.remove("visible"); }, 2600);
}

function dibujarBarras(contenedor, datos, sufijo) {
    const max = Math.max.apply(null, datos.map(function (d) { return d[1]; })) || 1;
    $(contenedor).innerHTML = datos.map(function (d) {
        const alto = Math.round((d[1] / max) * 80);
        const pico = d[1] === max && max > 0 ? " pico" : "";
        return '<div class="barra-col" title="' + d[0] + ': ' + d[1] + (sufijo || "") + '">' +
            '<div class="barra-area"><span class="v">' + d[1] + '</span>' +
            '<div class="b' + pico + '" style="height:' + alto + '%"></div></div>' +
            '<small>' + d[0] + '</small></div>';
    }).join("");
}

function filaHbar(nombre, valor, maximo, nivel, textoValor) {
    const ancho = maximo ? Math.round((valor / maximo) * 100) : 0;
    return '<div class="hbar"><span class="nombre">' + esc(nombre) + '</span>' +
        '<div class="pista"><div class="relleno ' + nivel + '" style="width:' + ancho + '%"></div></div>' +
        '<span class="valor">' + textoValor + '</span></div>';
}

/* =====================================================
   NAVEGACIÓN
===================================================== */

const informacionPaginas = {
    resumen: ["Resumen de la sede", "Mira cómo va la fila de tu sede en este momento."],
    fila: ["Fila actual", "Llama turnos, agrega clientes y ajusta las cajas abiertas."],
    sedes: ["Sedes", "Administra todas las sedes de tu franquicia."],
    perfil: ["Mi establecimiento", "Edita la información que ven los clientes en QueueVision."],
    estadisticas: ["Estadísticas", "Revisa la afluencia y los tiempos de espera."],
    configuracion: ["Configuración", "Ajusta las notificaciones y los umbrales del panel."]
};

function mostrarPagina(nombre) {
    if (!informacionPaginas[nombre]) nombre = "resumen";

    document.querySelectorAll(".pagina").forEach(function (p) {
        p.classList.toggle("activa-pagina", p.id === nombre);
    });
    document.querySelectorAll(".menu-item").forEach(function (a) {
        a.classList.toggle("activo", a.getAttribute("href") === "#" + nombre);
    });

    $("#tituloPagina").textContent = informacionPaginas[nombre][0];
    $("#descripcionPagina").textContent = informacionPaginas[nombre][1];
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function paginaDesdeURL() {
    return window.location.hash.replace("#", "") || "resumen";
}

document.querySelectorAll('a[href^="#"]').forEach(function (enlace) {
    enlace.addEventListener("click", function (e) {
        e.preventDefault();
        const destino = enlace.getAttribute("href").replace("#", "");
        if (destino !== paginaDesdeURL()) history.pushState({}, "", "#" + destino);
        mostrarPagina(destino);
    });
});

window.addEventListener("popstate", function () { mostrarPagina(paginaDesdeURL()); });

/* =====================================================
   SELECTOR DE SEDE
===================================================== */

let firmaSelector = "";

function renderSelector() {
    const firma = sedes.map(function (s) { return s.id + s.nombre; }).join("|") + "#" + sedeId;
    if (firma === firmaSelector) return;
    firmaSelector = firma;

    $("#selectorSede").innerHTML = sedes.map(function (s) {
        return '<option value="' + s.id + '"' + (s.id === sedeId ? " selected" : "") + '>' + esc(s.nombre) + (s.abierta ? "" : " (cerrada)") + '</option>';
    }).join("");
}

$("#selectorSede").addEventListener("change", function () {
    sedeId = Number(this.value);
    renderTodo();
});

function seleccionarSede(id) {
    sedeId = id;
    renderTodo();
}

/* =====================================================
   RESUMEN
===================================================== */

function renderResumen() {
    const s = sedeActual();
    const c = calcular(s);

    $("#estadoSede").innerHTML =
        '<div><h2>' + esc(s.nombre) + ' ' + badgeSede(s) + '</h2><p>' + esc(s.direccion || "Sin dirección") + '</p></div>' +
        '<button type="button" class="boton-secundario ' + (s.abierta ? "boton-cerrar" : "") + '" data-accion="alternar" data-id="' + s.id + '">' +
        '<i class="fa-solid ' + (s.abierta ? "fa-lock" : "fa-lock-open") + '"></i> ' + (s.abierta ? "Cerrar sede" : "Abrir sede") + '</button>';

    const kpis = [
        ["fa-people-line", s.fila.length, "Personas en fila"],
        ["fa-clock", s.abierta ? c.espera + " min" : "—", "Espera estimada"],
        ["fa-circle-check", s.atendidos, "Atendidos hoy"],
        ["fa-cash-register", s.abierta ? s.cajas : 0, "Cajas abiertas"]
    ];
    $("#kpis").innerHTML = kpis.map(function (k) {
        return '<div class="kpi"><i class="fa-solid ' + k[0] + '"></i><div><strong>' + k[1] + '</strong><span>' + k[2] + '</span></div></div>';
    }).join("");

    $("#ocupacion").innerHTML =
        '<div class="ocupacion-grande"><strong>' + (s.abierta ? c.pct : 0) + '%</strong>' + badgeSede(s) + '</div>' +
        '<div class="pista"><div class="relleno ' + c.nivel + '" style="width:' + (s.abierta ? c.pct : 0) + '%"></div></div>' +
        '<div class="ocupacion-detalle"><span><strong>' + s.fila.length + '</strong> de ' + s.capacidad + ' lugares en la fila</span>' +
        '<span>Tiempo por persona: <strong>' + s.minutos + ' min</strong></span></div>';

    const suma = perfilHoras.reduce(function (a, b) { return a + b; }, 0);
    dibujarBarras("#graficaHoras", horas.map(function (h, i) {
        return [h, Math.round((perfilHoras[i] / suma) * s.atendidos)];
    }));

    $("#siguientes").innerHTML = s.fila.slice(0, 4).map(function (t, i) {
        const falta = Math.round(((i + 1) * s.minutos) / Math.max(1, s.cajas));
        return '<li><span class="turno">' + t.turno + '</span><div class="info"><strong>' + esc(t.nombre) + '</strong>' +
            '<small>' + t.origen + ' · lleva ' + minutosDesde(t.llegada) + ' min</small></div><span class="suave">≈ ' + falta + ' min</span></li>';
    }).join("") || '<li class="vacio-texto">' + (s.abierta ? "No hay nadie en la fila." : "La sede está cerrada.") + '</li>';

    $("#historialAvisos").innerHTML = s.avisos.slice(0, 4).map(function (a) {
        return '<li>' + esc(a.texto) + '<small>' + a.hora + ' · enviado a ' + a.destinatarios + ' cliente(s)</small></li>';
    }).join("");
}

$("#estadoSede").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-accion='alternar']");
    if (boton) alternarSede(Number(boton.dataset.id));
});

function alternarSede(id) {
    const s = sedes.find(function (x) { return x.id === id; });
    if (!s) return;

    if (s.abierta) {
        const personas = s.fila.length + (s.llamado ? 1 : 0);
        if (personas && !confirm("Hay " + personas + " persona(s) en la fila. Si cierras la sede, la fila se vaciará. ¿Continuar?")) return;
        s.abierta = false;
        s.fila = [];
        s.llamado = null;
        mostrarToast(s.nombre + " cerrada");
    } else {
        s.abierta = true;
        s.cajas = Math.max(1, s.cajas);
        mostrarToast(s.nombre + " abierta");
    }
    renderTodo();
}

$("#formAviso").addEventListener("submit", function (e) {
    e.preventDefault();
    const s = sedeActual();
    const texto = $("#textoAviso").value.trim();

    if (texto.length < 3) { mostrarToast("Escribe el mensaje del aviso."); return; }

    const destinatarios = s.fila.filter(function (t) { return t.origen === "App"; }).length;
    if (!destinatarios) { mostrarToast("No hay clientes de la app en la fila para avisar."); return; }

    s.avisos.unshift({
        texto: texto, destinatarios: destinatarios,
        hora: new Date().toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" })
    });
    $("#textoAviso").value = "";
    renderResumen();
    mostrarToast("Aviso enviado a " + destinatarios + " cliente(s)");
});

/* =====================================================
   FILA ACTUAL
===================================================== */

function renderFila() {
    const s = sedeActual();

    $("#btnLlamar").disabled = !s.abierta || !!s.llamado || !s.fila.length;
    $("#btnAgregar").disabled = !s.abierta;
    $("#numCajas").textContent = s.abierta ? s.cajas : 0;
    $("#btnMenosCaja").disabled = !s.abierta || s.cajas <= 1;
    $("#btnMasCaja").disabled = !s.abierta || s.cajas >= 12;

    $("#turnoLlamado").innerHTML = s.llamado
        ? '<div class="turno-llamado"><div><span>Turno llamado</span><strong>' + s.llamado.turno + '</strong>' +
          '<small>' + esc(s.llamado.nombre) + ' · Caja ' + s.llamado.caja + '</small></div>' +
          '<div class="acciones"><button type="button" class="boton-principal" data-turno="atendido"><i class="fa-solid fa-check"></i> Marcar atendido</button>' +
          '<button type="button" class="boton-secundario" data-turno="ausente">No se presentó</button></div></div>'
        : "";

    $("#tablaFila").innerHTML = s.fila.map(function (t, i) {
        const falta = Math.round(((i + 1) * s.minutos) / Math.max(1, s.cajas));
        return '<tr><td><strong>' + t.turno + '</strong></td><td>' + esc(t.nombre) + '</td>' +
            '<td><span class="badge ' + (t.origen === "App" ? "admin" : "inactivo") + '">' + t.origen + '</span></td>' +
            '<td>' + minutosDesde(t.llegada) + ' min</td><td>≈ ' + falta + ' min</td>' +
            '<td><div class="acciones"><button type="button" class="btn-icono peligro" data-quitar="' + t.turno + '" aria-label="Quitar el turno ' + t.turno + ' de la fila"><i class="fa-solid fa-xmark"></i></button></div></td></tr>';
    }).join("") || '<tr class="fila-vacia"><td colspan="6">' + (s.abierta ? "No hay nadie en la fila." : "La sede está cerrada.") + '</td></tr>';
}

$("#btnLlamar").addEventListener("click", function () {
    const s = sedeActual();
    if (!s.fila.length || s.llamado) return;
    s.llamado = s.fila.shift();
    s.llamadas++;
    s.llamado.caja = ((s.llamadas - 1) % s.cajas) + 1;
    mostrarToast("Turno " + s.llamado.turno + " llamado a la caja " + s.llamado.caja);
    renderTodo();
});

$("#turnoLlamado").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-turno]");
    if (!boton) return;
    const s = sedeActual();

    if (boton.dataset.turno === "atendido") { s.atendidos++; mostrarToast("Turno " + s.llamado.turno + " atendido"); }
    else { s.noShow++; mostrarToast("Turno " + s.llamado.turno + " marcado como ausente"); }
    s.llamado = null;
    renderTodo();
});

$("#tablaFila").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-quitar]");
    if (!boton) return;
    const s = sedeActual();
    s.fila = s.fila.filter(function (t) { return t.turno !== boton.dataset.quitar; });
    mostrarToast("Turno " + boton.dataset.quitar + " quitado de la fila");
    renderTodo();
});

$("#btnMasCaja").addEventListener("click", function () { cambiarCajas(1); });
$("#btnMenosCaja").addEventListener("click", function () { cambiarCajas(-1); });

function cambiarCajas(delta) {
    const s = sedeActual();
    if (!s.abierta) return;
    s.cajas = Math.max(1, Math.min(12, s.cajas + delta));
    renderTodo();
}

/* ---------- Agregar cliente ---------- */

$("#btnAgregar").addEventListener("click", function () {
    $("#clienteNombre").value = "";
    $("#errorCliente").textContent = "";
    abrirModal("#modalCliente", "#clienteNombre");
});

$("#formCliente").addEventListener("submit", function (e) {
    e.preventDefault();
    const s = sedeActual();

    if (s.fila.length >= s.capacidad) {
        $("#errorCliente").textContent = "La fila llegó a su capacidad máxima (" + s.capacidad + ").";
        return;
    }
    const t = nuevoTicket(s, "Presencial", $("#clienteNombre").value.trim() || "Cliente");
    s.fila.push(t);
    cerrarModales();
    renderTodo();
    mostrarToast("Turno " + t.turno + " agregado a la fila");
});

/* =====================================================
   SEDES
===================================================== */

function renderSedes() {
    const abiertas = sedes.filter(function (s) { return s.abierta; }).length;
    $("#resumenSedes").textContent = sedes.length + " sede(s) · " + abiertas + " abierta(s)";

    $("#gridSedes").innerHTML = sedes.map(function (s) {
        const c = calcular(s);
        return '<article class="tarjeta-fila' + (s.abierta ? "" : " inactiva") + (s.id === sedeId ? " seleccionada" : "") + '">' +
            '<header><div><h3>' + esc(s.nombre) + '</h3><p class="direccion">' + esc(s.direccion || "Sin dirección") + '</p></div>' + badgeSede(s) + '</header>' +
            '<div class="pista"><div class="relleno ' + c.nivel + '" style="width:' + (s.abierta ? c.pct : 0) + '%"></div></div>' +
            '<div class="fila-cifras">' +
            '<div><strong>' + s.fila.length + '</strong><span>En fila</span></div>' +
            '<div><strong>' + (s.abierta ? c.espera : 0) + ' min</strong><span>Espera</span></div>' +
            '<div><strong>' + (s.abierta ? s.cajas : 0) + '</strong><span>Cajas</span></div></div>' +
            '<div class="fila-controles">' +
            '<button type="button" class="boton-secundario" data-accion="ver" data-id="' + s.id + '">' + (s.id === sedeId ? "Seleccionada" : "Ver sede") + '</button>' +
            '<button type="button" class="btn-icono" data-accion="alternar" data-id="' + s.id + '" aria-label="' + (s.abierta ? "Cerrar " : "Abrir ") + esc(s.nombre) + '"><i class="fa-solid ' + (s.abierta ? "fa-lock" : "fa-lock-open") + '"></i></button>' +
            '<button type="button" class="btn-icono" data-accion="editar" data-id="' + s.id + '" aria-label="Editar ' + esc(s.nombre) + '"><i class="fa-solid fa-pen"></i></button>' +
            '<button type="button" class="btn-icono peligro" data-accion="eliminar" data-id="' + s.id + '" aria-label="Eliminar ' + esc(s.nombre) + '"' + (sedes.length === 1 ? " disabled" : "") + '><i class="fa-solid fa-trash"></i></button>' +
            '</div></article>';
    }).join("");
}

$("#gridSedes").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-accion]");
    if (!boton || boton.disabled) return;
    const id = Number(boton.dataset.id);

    if (boton.dataset.accion === "ver") { seleccionarSede(id); mostrarToast("Sede seleccionada"); }
    if (boton.dataset.accion === "alternar") alternarSede(id);
    if (boton.dataset.accion === "editar") abrirFormularioSede(id);
    if (boton.dataset.accion === "eliminar") {
        const s = sedes.find(function (x) { return x.id === id; });
        if (s && sedes.length > 1 && confirm('¿Eliminar la sede "' + s.nombre + '"? Esta acción no se puede deshacer.')) {
            sedes = sedes.filter(function (x) { return x.id !== id; });
            if (sedeId === id) sedeId = sedes[0].id;
            renderTodo();
            mostrarToast("Sede eliminada");
        }
    }
});

$("#btnNuevaSede").addEventListener("click", function () { abrirFormularioSede(null); });

function abrirFormularioSede(id) {
    const s = id ? sedes.find(function (x) { return x.id === id; }) : null;
    $("#tituloSede").textContent = s ? "Editar sede" : "Nueva sede";
    $("#sedeIdForm").value = s ? s.id : "";
    $("#sedeNombre").value = s ? s.nombre : "";
    $("#sedeDireccion").value = s ? s.direccion : "";
    $("#sedeCapacidad").value = s ? s.capacidad : 20;
    $("#sedeMinutos").value = s ? s.minutos : 3;
    $("#sedeCajas").value = s ? s.cajas : 2;
    $("#errorSede").textContent = "";
    abrirModal("#modalSede", "#sedeNombre");
}

$("#formSede").addEventListener("submit", function (e) {
    e.preventDefault();

    const id = Number($("#sedeIdForm").value) || null;
    const nombre = $("#sedeNombre").value.trim();
    const capacidad = Number($("#sedeCapacidad").value);
    const minutos = Number($("#sedeMinutos").value);
    const cajas = Number($("#sedeCajas").value);
    const existente = id ? sedes.find(function (s) { return s.id === id; }) : null;

    let error = "";
    if (!nombre) error = "Escribe el nombre de la sede.";
    else if (sedes.some(function (s) { return s.id !== id && s.nombre.toLowerCase() === nombre.toLowerCase(); })) error = "Ya existe una sede con ese nombre.";
    else if (!(capacidad >= 1)) error = "La capacidad debe ser de al menos 1 persona.";
    else if (existente && capacidad < existente.fila.length) error = "La capacidad no puede ser menor que la fila actual (" + existente.fila.length + ").";
    else if (!(minutos > 0)) error = "Los minutos por persona deben ser mayores que 0.";
    else if (!(Number.isInteger(cajas) && cajas >= 1 && cajas <= 12)) error = "Las cajas deben ser un número entre 1 y 12.";

    if (error) { $("#errorSede").textContent = error; return; }

    const datos = { nombre: nombre, direccion: $("#sedeDireccion").value.trim(), capacidad: capacidad, minutos: minutos, cajas: cajas };

    if (existente) {
        Object.assign(existente, datos);
        mostrarToast("Sede actualizada");
    } else {
        const nueva = crearSede(datos, 0);
        sedes.push(nueva);
        sedeId = nueva.id;
        mostrarToast("Sede creada");
    }
    cerrarModales();
    renderTodo();
});

/* =====================================================
   MI ESTABLECIMIENTO
===================================================== */

function llenarFormularioPerfil() {
    $("#perfilNombre").value = franquicia.nombre;
    $("#perfilTipo").value = franquicia.tipo;
    $("#perfilHorario").value = franquicia.horario;
    $("#perfilDescripcion").value = franquicia.descripcion;
    $("#perfilTelefono").value = franquicia.telefono;
    $("#perfilDestacados").value = franquicia.destacados.join(", ");

    $("#listaServicios").innerHTML = catalogoServicios.map(function (s) {
        const activo = franquicia.servicios.includes(s[0]);
        return '<label class="chip-servicio' + (activo ? " activo" : "") + '"><input type="checkbox" value="' + s[0] + '"' + (activo ? " checked" : "") + '>' +
            '<i class="fa-solid ' + s[1] + '"></i> ' + s[2] + '</label>';
    }).join("");
}

function leerPerfil() {
    return {
        nombre: $("#perfilNombre").value.trim(),
        tipo: $("#perfilTipo").value,
        horario: $("#perfilHorario").value.trim(),
        descripcion: $("#perfilDescripcion").value.trim(),
        telefono: $("#perfilTelefono").value.trim(),
        destacados: $("#perfilDestacados").value.split(",").map(function (d) { return d.trim(); }).filter(Boolean),
        servicios: Array.from(document.querySelectorAll("#listaServicios input:checked")).map(function (i) { return i.value; })
    };
}

function iconoTipo(tipo) {
    return tipo === "Almacén de cadena" ? "fa-store" : tipo === "Restaurante" ? "fa-utensils" : "fa-shop";
}

function renderVistaPrevia() {
    const p = leerPerfil();
    const s = sedeActual();
    const c = calcular(s);

    const estado = s.abierta
        ? '<div class="estado-mini ' + c.nivel + '"><span>' + textoNivel[c.nivel] + ' · ' + esc(s.nombre) + '</span><span>' + s.fila.length + ' en fila · ' + c.espera + ' min</span></div>'
        : '<div class="estado-mini cerrado"><span>Cerrado · ' + esc(s.nombre) + '</span></div>';

    const servicios = catalogoServicios.filter(function (x) { return p.servicios.includes(x[0]); }).map(function (x) {
        return '<li><i class="fa-solid ' + x[1] + '"></i> ' + x[2] + '</li>';
    }).join("");

    $("#vistaPrevia").innerHTML =
        '<div class="cabecera"><div class="icono-lugar ' + (p.tipo === "Almacén de cadena" ? "almacen" : "restaurante") + '" style="min-width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;color:white;background:' + (p.tipo === "Almacén de cadena" ? "#32136b" : "#7134d5") + '"><i class="fa-solid ' + iconoTipo(p.tipo) + '"></i></div>' +
        '<div><h3>' + esc(p.nombre || "Sin nombre") + '</h3><p>' + esc(p.tipo) + (p.horario ? " · " + esc(p.horario) : "") + '</p></div></div>' +
        estado +
        '<h4>Descripción</h4><p class="texto">' + (esc(p.descripcion) || "Aún no has escrito una descripción.") + '</p>' +
        '<h4>Lo que ofrece</h4>' + (servicios ? '<ul class="servicios">' + servicios + '</ul>' : '<p class="texto">No has marcado servicios.</p>') +
        (p.destacados.length ? '<h4>Destacados</h4><p class="texto">' + p.destacados.map(esc).join(" · ") + '</p>' : "") +
        (p.telefono ? '<h4>Contacto</h4><p class="texto"><i class="fa-solid fa-phone"></i> ' + esc(p.telefono) + '</p>' : "");
}

$("#formPerfil").addEventListener("input", function (e) {
    if (e.target.type === "checkbox") e.target.closest(".chip-servicio").classList.toggle("activo", e.target.checked);
    renderVistaPrevia();
});

$("#formPerfil").addEventListener("submit", function (e) {
    e.preventDefault();
    const p = leerPerfil();

    if (!p.nombre) { $("#errorPerfil").textContent = "Escribe el nombre del establecimiento."; return; }
    if (p.descripcion.length < 20) { $("#errorPerfil").textContent = "La descripción debe tener al menos 20 caracteres."; return; }
    $("#errorPerfil").textContent = "";

    Object.assign(franquicia, p);
    $("#nombreLocal").textContent = franquicia.nombre;
    $("#avatarLocal").textContent = franquicia.nombre.charAt(0).toUpperCase();
    mostrarToast("Información guardada");
});

/* =====================================================
   ESTADÍSTICAS
===================================================== */

function renderEstadisticas() {
    const s = sedeActual();
    const factor = s.capacidad / 23;

    $("#subtituloStats").textContent = "Sede: " + s.nombre + " · datos de ejemplo.";

    dibujarBarras("#graficaSemana", dias.map(function (d, i) { return [d, Math.round(semanaBase[i] * factor)]; }), " visitas");
    dibujarBarras("#graficaEsperaHoras", horas.map(function (h, i) {
        return [h, Math.round(esperaHoras[i] * (s.minutos / 3))];
    }), " min");

    const abiertas = sedes.filter(function (x) { return x.abierta; });
    const maxEspera = Math.max.apply(null, abiertas.map(function (x) { return calcular(x).espera; })) || 1;
    $("#comparativo").innerHTML = abiertas.map(function (x) {
        const c = calcular(x);
        return filaHbar(x.nombre.replace(franquicia.nombre + " ", ""), c.espera, maxEspera, c.nivel, c.espera + " min");
    }).join("") || '<p class="vacio-texto">No hay sedes abiertas.</p>';

    const total = s.atendidos + s.noShow;
    const pctAtendidos = total ? Math.round((s.atendidos / total) * 100) : 0;
    $("#resultadoTurnos").innerHTML =
        filaHbar("Atendidos", s.atendidos, total, "vacio", s.atendidos) +
        filaHbar("No se presentó", s.noShow, total, "lleno", s.noShow) +
        '<p class="suave" style="font-size:14px;margin-top:6px">' + (total ? pctAtendidos + "% de los turnos terminó en atención." : "Aún no hay turnos finalizados hoy.") + '</p>';
}

$("#btnExportar").addEventListener("click", function () {
    const filas = [["Sede", "Abierta", "En fila", "Capacidad", "Ocupación %", "Espera (min)", "Cajas", "Atendidos hoy", "No se presentó"]];
    sedes.forEach(function (s) {
        const c = calcular(s);
        filas.push([s.nombre, s.abierta ? "Sí" : "No", s.fila.length, s.capacidad, c.pct, c.espera, s.abierta ? s.cajas : 0, s.atendidos, s.noShow]);
    });

    const csv = filas.map(function (fila) {
        return fila.map(function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(",");
    }).join("\n");

    const enlace = document.createElement("a");
    enlace.href = URL.createObjectURL(new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" }));
    enlace.download = "queuevision-sedes.csv";
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    URL.revokeObjectURL(enlace.href);
    mostrarToast("Reporte exportado");
});

/* =====================================================
   CONFIGURACIÓN
===================================================== */

$("#cfgLlegadas").addEventListener("change", function () { config.notifLlegadas = this.checked; });
$("#cfgSimulacion").addEventListener("change", function () { config.simulacion = this.checked; });

function actualizarUmbrales() {
    const moderado = Number($("#umbralModerado").value);
    const lleno = Number($("#umbralLleno").value);

    if (!(moderado >= 1) || !(lleno <= 100) || moderado >= lleno) {
        $("#mensajeUmbral").textContent = "El umbral de \"Moderado\" debe ser menor que el de \"Lleno\".";
        return;
    }
    $("#mensajeUmbral").textContent = "";
    config.moderado = moderado;
    config.lleno = lleno;
    renderTodo();
}
$("#umbralModerado").addEventListener("input", actualizarUmbrales);
$("#umbralLleno").addEventListener("input", actualizarUmbrales);

const modoOscuro = $("#modoOscuro");

function aplicarModo(oscuro) {
    document.body.classList.toggle("modo-oscuro", oscuro);
    modoOscuro.checked = oscuro;
}

let guardado = null;
try { guardado = localStorage.getItem("queuevisionLocalOscuro"); } catch (e) { /* sin almacenamiento */ }
aplicarModo(guardado === "true");

modoOscuro.addEventListener("change", function () {
    aplicarModo(modoOscuro.checked);
    try { localStorage.setItem("queuevisionLocalOscuro", String(modoOscuro.checked)); } catch (e) { /* ignorar */ }
});

/* =====================================================
   MODALES
===================================================== */

function abrirModal(selector, campoFoco) {
    const m = $(selector);
    m.classList.add("abierto");
    m.setAttribute("aria-hidden", "false");
    if (campoFoco) $(campoFoco).focus();
}

function cerrarModales() {
    document.querySelectorAll(".modal.abierto").forEach(function (m) {
        m.classList.remove("abierto");
        m.setAttribute("aria-hidden", "true");
    });
}

document.querySelectorAll(".modal").forEach(function (m) {
    m.addEventListener("click", function (e) {
        if (e.target === m || e.target.closest("[data-cerrar]")) cerrarModales();
    });
});
document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") cerrarModales();
});

/* =====================================================
   CERRAR SESIÓN
===================================================== */

$("#cerrarSesion").addEventListener("click", function () {
    if (confirm("¿Estás seguro de que deseas cerrar sesión?")) {
        // Cambia esta ruta si tu login está en otra ubicación
        window.location.href = "/HTML/login.html";
    }
});

/* =====================================================
   ACTUALIZACIÓN Y SIMULACIÓN
===================================================== */

function renderTodo() {
    renderSelector();
    renderResumen();
    renderFila();
    renderSedes();
    renderVistaPrevia();
    renderEstadisticas();
}

/* Cada 12 segundos: refresca los tiempos y, si está activado, simula llegadas */
setInterval(function () {
    if (config.simulacion) {
        sedes.forEach(function (s) {
            if (!s.abierta) return;

            if (Math.random() < 0.55 && s.fila.length < s.capacidad) {
                const t = nuevoTicket(s, Math.random() < 0.7 ? "App" : "Presencial");
                s.fila.push(t);
                if (config.notifLlegadas && s.id === sedeId && t.origen === "App") {
                    mostrarToast("Nuevo turno " + t.turno + " desde la app");
                }
            }
            /* Las demás sedes avanzan solas; la sede seleccionada la controlas tú */
            if (s.id !== sedeId && Math.random() < 0.4 && s.fila.length) {
                s.fila.shift();
                s.atendidos++;
            }
        });
    }
    renderTodo();
}, 12000);

/* =====================================================
   INICIO
===================================================== */

llenarFormularioPerfil();
renderTodo();
mostrarPagina(paginaDesdeURL());