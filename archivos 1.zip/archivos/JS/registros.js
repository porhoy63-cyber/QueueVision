const formulario = document.getElementById("formRegistro");
const mensaje = document.getElementById("mensajeRegistro");

formulario.addEventListener("submit", function(event) {

    event.preventDefault();

    const tipoDocumento = document.getElementById("tipoDocumento").value;
    const documento = document.getElementById("documento").value.trim();
    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const telefono = document.getElementById("telefono").value.trim();
    const password = document.getElementById("password").value;
    const confirmarPassword = document.getElementById("confirmarPassword").value;
    const terminos = document.getElementById("terminos").checked;

    const correoValido =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    const soloNumeros =
        /^[0-9]+$/;

    const soloLetras =
        /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;


    if (tipoDocumento === "") {
        mostrarError("Selecciona un tipo de documento.");
        return;
    }

    if (!soloNumeros.test(documento)) {
        mostrarError("El número de documento solo debe contener números.");
        return;
    }

    if (documento.length < 10) {
        mostrarError("El número de documento no es válido.");
        return;
    }

    if (!soloLetras.test(nombre)) {
        mostrarError("El nombre solo debe contener letras.");
        return;
    }

    if (!soloLetras.test(apellido)) {
        mostrarError("El apellido solo debe contener letras.");
        return;
    }

    if (!correoValido.test(correo)) {
        mostrarError("Ingresa un correo electrónico válido.");
        return;
    }

    if (!soloNumeros.test(telefono) || telefono.length < 10) {
        mostrarError("Ingresa un número de teléfono válido.");
        return;
    }

    if (password.length < 8) {
        mostrarError("La contraseña debe tener mínimo 8 caracteres.");
        return;
    }

    if (password !== confirmarPassword) {
        mostrarError("Las contraseñas no coinciden.");
        return;
    }

    if (!terminos) {
        mostrarError("Debes aceptar los términos y condiciones.");
        return;
    }


    mensaje.textContent =
        "Registro validado correctamente.";

    mensaje.className = "exito";


    setTimeout(function() {
        window.location.href = "login.html";
    }, 1500);

});

function mostrarError(texto) {

    mensaje.textContent = texto;

    mensaje.className = "error";
}

        function mostrarPassword() {
            const password = document.getElementById("password");
            const icono = document.querySelector(".mostrar-password i");

            if (password.type === "password") {
                password.type = "text";
                icono.classList.remove("fa-eye");
                icono.classList.add("fa-eye-slash");
            } else {
                password.type = "password";

                icono.classList.remove("fa-eye-slash");
                icono.classList.add("fa-eye");
            }
        }
function mostrarPassword(idCampo, boton) {

    const password = document.getElementById(idCampo);
    const icono = boton.querySelector("i");

    if (password.type === "password") {

        password.type = "text";

        icono.classList.remove("fa-eye");
        icono.classList.add("fa-eye-slash");

    } else {

        password.type = "password";

        icono.classList.remove("fa-eye-slash");
        icono.classList.add("fa-eye");

    }
}

        