/* QUEUEVISION - PANEL DE ADMINISTRACIÓN */

/* =====================================================
   DATOS DE EJEMPLO (luego pueden venir de tu API)
===================================================== */

let lugares = [
    { id: 1, nombre: "Burger House", tipo: "Restaurante", direccion: "Calle 45 #12-30", horario: "11:00 - 22:00", capacidad: 14, minutos: 1.25, enFila: 12, activo: true },
    { id: 2, nombre: "Pizza Planet", tipo: "Restaurante", direccion: "Carrera 9 #50-18", horario: "12:00 - 23:00", capacidad: 10, minutos: 2.5, enFila: 2, activo: true },
    { id: 3, nombre: "Éxito", tipo: "Almacén de cadena", direccion: "Avenida 68 #24-10", horario: "08:00 - 21:00", capacidad: 23, minutos: 1.1, enFila: 18, activo: true },
    { id: 4, nombre: "Café Central", tipo: "Restaurante", direccion: "Calle 72 #10-05", horario: "07:00 - 20:00", capacidad: 12, minutos: 2, enFila: 6, activo: true },
    { id: 5, nombre: "Ara", tipo: "Almacén de cadena", direccion: "Carrera 15 #85-20", horario: "08:00 - 20:00", capacidad: 15, minutos: 1, enFila: 4, activo: true },
    { id: 6, nombre: "Sushi Go", tipo: "Restaurante", direccion: "Calle 93 #11-40", horario: "12:00 - 22:00", capacidad: 8, minutos: 3, enFila: 0, activo: false }
];

let usuarios = [
    { id: 1, nombre: "Laura Gómez", correo: "laura@queuevision.com", tipo: "Administrador", estado: "Activo", registro: "2026-01-12" },
    { id: 2, nombre: "David Santos", correo: "usuario@correo.com", tipo: "Usuario", estado: "Activo", registro: "2026-02-03" },
    { id: 3, nombre: "María Rojas", correo: "maria.rojas@correo.com", tipo: "Usuario", estado: "Activo", registro: "2026-03-18" },
    { id: 4, nombre: "Carlos Pérez", correo: "carlos.p@correo.com", tipo: "Usuario", estado: "Bloqueado", registro: "2026-04-02" },
    { id: 5, nombre: "Ana Torres", correo: "ana.torres@correo.com", tipo: "Usuario", estado: "Activo", registro: "2026-05-21" },
    { id: 6, nombre: "Julián Ruiz", correo: "julian.ruiz@correo.com", tipo: "Usuario", estado: "Activo", registro: "2026-06-09" },
    { id: 7, nombre: "Sofía Mejía", correo: "sofia.m@correo.com", tipo: "Usuario", estado: "Activo", registro: "2026-08-30" }
];

const afluenciaHoras = [
    ["8", 12], ["9", 20], ["10", 28], ["11", 45], ["12", 78], ["13", 85],
    ["14", 52], ["15", 30], ["16", 34], ["17", 48], ["18", 70], ["19", 64]
];
const visitasSemana = [["Lun", 320], ["Mar", 290], ["Mié", 340], ["Jue", 380], ["Vie", 510], ["Sáb", 620], ["Dom", 450]];

const config = { moderado: 35, lleno: 70, alertas: true };
let siguienteIdLugar = 7;
let enVivo = true;

/* =====================================================
   UTILIDADES
===================================================== */

const $ = function (selector) { return document.querySelector(selector); };

function esc(texto) {
    const d = document.createElement("div");
    d.textContent = texto;
    return d.innerHTML;
}

function calcular(lugar) {
    const pct = Math.min(100, Math.round((lugar.enFila / lugar.capacidad) * 100));
    const espera = Math.round(lugar.enFila * lugar.minutos);
    let nivel = "vacio";
    if (pct >= config.lleno) nivel = "lleno";
    else if (pct >= config.moderado) nivel = "moderado";
    return { pct: pct, espera: espera, nivel: nivel };
}

const textoNivel = { lleno: "Lleno", moderado: "Moderado", vacio: "Vacío" };

function icono(lugar) {
    return lugar.tipo === "Almacén de cadena" ? "fa-store" : lugar.tipo === "Restaurante" ? "fa-utensils" : "fa-shop";
}

function badgeEstado(lugar) {
    if (!lugar.activo) return '<span class="badge inactivo">Inactivo</span>';
    const n = calcular(lugar).nivel;
    return '<span class="badge ' + n + '"><i class="fa-solid fa-circle"></i> ' + textoNivel[n] + '</span>';
}

function activos() {
    return lugares.filter(function (l) { return l.activo; });
}

let temporizadorToast;
function mostrarToast(mensaje) {
    const toast = $("#toast");
    toast.textContent = mensaje;
    toast.classList.add("visible");
    clearTimeout(temporizadorToast);
    temporizadorToast = setTimeout(function () { toast.classList.remove("visible"); }, 2600);
}

/* =====================================================
   NAVEGACIÓN
===================================================== */

const informacionPaginas = {
    resumen: ["Resumen general", "Así están las filas de tus establecimientos ahora mismo."],
    establecimientos: ["Establecimientos", "Crea, edita y activa los lugares que aparecen en QueueVision."],
    filas: ["Filas en vivo", "Controla cuántas personas hay en cada fila."],
    usuarios: ["Usuarios", "Consulta y administra las cuentas registradas."],
    reportes: ["Reportes", "Revisa la afluencia y los tiempos de espera."],
    configuracion: ["Configuración", "Ajusta las alertas y los umbrales del panel."]
};

function mostrarPagina(nombre) {
    if (!informacionPaginas[nombre]) nombre = "resumen";

    document.querySelectorAll(".pagina").forEach(function (p) {
        p.classList.toggle("activa-pagina", p.id === nombre);
    });
    document.querySelectorAll(".menu-item").forEach(function (a) {
        a.classList.toggle("activo", a.getAttribute("href") === "#" + nombre);
    });

    $("#tituloPagina").textContent = informacionPaginas[nombre][0];
    $("#descripcionPagina").textContent = informacionPaginas[nombre][1];
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function paginaDesdeURL() {
    return window.location.hash.replace("#", "") || "resumen";
}

document.querySelectorAll('a[href^="#"]').forEach(function (enlace) {
    enlace.addEventListener("click", function (e) {
        e.preventDefault();
        const destino = enlace.getAttribute("href").replace("#", "");
        if (destino !== paginaDesdeURL()) history.pushState({}, "", "#" + destino);
        mostrarPagina(destino);
    });
});

window.addEventListener("popstate", function () { mostrarPagina(paginaDesdeURL()); });

/* =====================================================
   RESUMEN
===================================================== */

function dibujarBarras(contenedor, datos, sufijo) {
    const max = Math.max.apply(null, datos.map(function (d) { return d[1]; })) || 1;
    $(contenedor).innerHTML = datos.map(function (d) {
        const alto = Math.round((d[1] / max) * 80);
        const pico = d[1] === max ? " pico" : "";
        return '<div class="barra-col" title="' + d[0] + ': ' + d[1] + (sufijo || "") + '">' +
            '<div class="barra-area"><span class="v">' + d[1] + '</span>' +
            '<div class="b' + pico + '" style="height:' + alto + '%"></div></div>' +
            '<small>' + d[0] + '</small></div>';
    }).join("");
}

function renderResumen() {
    const act = activos();
    const totalFila = act.reduce(function (s, l) { return s + l.enFila; }, 0);
    const esperaProm = act.length
        ? Math.round(act.reduce(function (s, l) { return s + calcular(l).espera; }, 0) / act.length) : 0;

    const kpis = [
        ["fa-store", act.length + " / " + lugares.length, "Establecimientos activos"],
        ["fa-people-line", totalFila, "Personas en fila ahora"],
        ["fa-clock", esperaProm + " min", "Espera promedio"],
        ["fa-users", usuarios.length, "Usuarios registrados"]
    ];
    $("#kpis").innerHTML = kpis.map(function (k) {
        return '<div class="kpi"><i class="fa-solid ' + k[0] + '"></i><div><strong>' + k[1] + '</strong><span>' + k[2] + '</span></div></div>';
    }).join("");

    /* Distribución de estados */
    const conteo = { lleno: 0, moderado: 0, vacio: 0 };
    act.forEach(function (l) { conteo[calcular(l).nivel]++; });
    const total = act.length || 1;
    $("#totalActivos").textContent = act.length + " activos";
    $("#distribucion").innerHTML =
        '<div class="apilada">' + ["lleno", "moderado", "vacio"].map(function (n) {
            return '<div class="' + n + '" style="width:' + (conteo[n] / total * 100) + '%"></div>';
        }).join("") + '</div>' +
        '<div class="leyenda">' + ["lleno", "moderado", "vacio"].map(function (n) {
            return '<div class="' + n + '"><span><i class="fa-solid fa-circle"></i>' + textoNivel[n] + '</span><strong>' + conteo[n] + '</strong></div>';
        }).join("") + '</div>';

    /* Alertas */
    const alertas = [];
    if (config.alertas) {
        act.forEach(function (l) {
            const c = calcular(l);
            if (c.nivel === "lleno") {
                alertas.push('<li class="peligro"><i class="fa-solid fa-triangle-exclamation"></i><div>' + esc(l.nombre) +
                    ' está llena (' + c.pct + '%)<small>' + l.enFila + ' personas · espera de ' + c.espera + ' min</small></div></li>');
            }
        });
    }
    const bloqueados = usuarios.filter(function (u) { return u.estado === "Bloqueado"; }).length;
    if (bloqueados) {
        alertas.push('<li class="info"><i class="fa-solid fa-user-lock"></i><div>' + bloqueados +
            ' usuario(s) bloqueado(s)<small>Revísalos en la sección Usuarios</small></div></li>');
    }
    if (lugares.some(function (l) { return !l.activo; })) {
        alertas.push('<li class="info"><i class="fa-solid fa-eye-slash"></i><div>Hay establecimientos inactivos<small>No aparecen en la app de los usuarios</small></div></li>');
    }
    if (!alertas.length) {
        alertas.push('<li class="ok"><i class="fa-solid fa-circle-check"></i><div>Todo en orden<small>No hay alertas por ahora</small></div></li>');
    }
    $("#alertas").innerHTML = alertas.join("");

    /* Más ocupados */
    const top = act.slice().sort(function (a, b) { return calcular(b).pct - calcular(a).pct; }).slice(0, 4);
    $("#topLugares").innerHTML = top.map(function (l) {
        const c = calcular(l);
        return '<div class="hbar"><span class="nombre">' + esc(l.nombre) + '</span>' +
            '<div class="pista"><div class="relleno ' + c.nivel + '" style="width:' + c.pct + '%"></div></div>' +
            '<span class="valor">' + c.pct + '%</span></div>';
    }).join("") || '<p class="suave">No hay establecimientos activos.</p>';
}

/* =====================================================
   ESTABLECIMIENTOS
===================================================== */

function renderTablaLugares() {
    const texto = $("#buscadorLugares").value.toLowerCase().trim();
    const tipo = $("#filtroTipo").value;
    const estado = $("#filtroEstado").value;

    const filtrados = lugares.filter(function (l) {
        if (texto && !(l.nombre + " " + l.direccion).toLowerCase().includes(texto)) return false;
        if (tipo && l.tipo !== tipo) return false;
        if (estado === "inactivo") return !l.activo;
        if (estado) return l.activo && calcular(l).nivel === estado;
        return true;
    });

    $("#tablaLugares").innerHTML = filtrados.map(function (l) {
        const c = calcular(l);
        return '<tr>' +
            '<td><div class="celda-lugar"><div class="mini-icono ' + (l.tipo === "Almacén de cadena" ? "almacen" : "") + '"><i class="fa-solid ' + icono(l) + '"></i></div>' +
            '<div><strong>' + esc(l.nombre) + '</strong><small>' + esc(l.direccion || "Sin dirección") + '</small></div></div></td>' +
            '<td>' + esc(l.tipo) + '</td>' +
            '<td>' + l.enFila + ' / ' + l.capacidad + '</td>' +
            '<td>' + badgeEstado(l) + '</td>' +
            '<td>' + (l.activo ? c.espera + ' min' : '—') + '</td>' +
            '<td><label class="switch"><input type="checkbox" data-accion="activar" data-id="' + l.id + '"' + (l.activo ? ' checked' : '') +
            ' aria-label="Activar ' + esc(l.nombre) + '"><span></span></label></td>' +
            '<td><div class="acciones">' +
            '<button type="button" class="btn-icono" data-accion="editar" data-id="' + l.id + '" aria-label="Editar ' + esc(l.nombre) + '"><i class="fa-solid fa-pen"></i></button>' +
            '<button type="button" class="btn-icono peligro" data-accion="eliminar" data-id="' + l.id + '" aria-label="Eliminar ' + esc(l.nombre) + '"><i class="fa-solid fa-trash"></i></button>' +
            '</div></td></tr>';
    }).join("") || '<tr class="fila-vacia"><td colspan="7">No se encontraron establecimientos con esos filtros.</td></tr>';
}

["#buscadorLugares", "#filtroTipo", "#filtroEstado"].forEach(function (id) {
    $(id).addEventListener("input", renderTablaLugares);
});

$("#tablaLugares").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-accion]");
    if (!boton) return;
    const id = Number(boton.dataset.id);

    if (boton.dataset.accion === "editar") abrirFormulario(id);

    if (boton.dataset.accion === "eliminar") {
        const lugar = lugares.find(function (l) { return l.id === id; });
        if (lugar && confirm('¿Eliminar "' + lugar.nombre + '"? Esta acción no se puede deshacer.')) {
            lugares = lugares.filter(function (l) { return l.id !== id; });
            renderTodo();
            mostrarToast("Establecimiento eliminado");
        }
    }
});

$("#tablaLugares").addEventListener("change", function (e) {
    if (e.target.dataset.accion !== "activar") return;
    const lugar = lugares.find(function (l) { return l.id === Number(e.target.dataset.id); });
    lugar.activo = e.target.checked;
    if (!lugar.activo) lugar.enFila = 0;
    renderTodo();
    mostrarToast(lugar.nombre + (lugar.activo ? " activado" : " desactivado"));
});

/* ---------- Modal / formulario ---------- */

const modal = $("#modalLugar");

function abrirFormulario(id) {
    const lugar = id ? lugares.find(function (l) { return l.id === id; }) : null;

    $("#tituloFormulario").textContent = lugar ? "Editar establecimiento" : "Nuevo establecimiento";
    $("#lugarId").value = lugar ? lugar.id : "";
    $("#lugarNombre").value = lugar ? lugar.nombre : "";
    $("#lugarDireccion").value = lugar ? lugar.direccion : "";
    $("#lugarTipo").value = lugar ? lugar.tipo : "Restaurante";
    $("#lugarHorario").value = lugar ? lugar.horario : "";
    $("#lugarCapacidad").value = lugar ? lugar.capacidad : 10;
    $("#lugarMinutos").value = lugar ? lugar.minutos : 2;
    $("#errorForm").textContent = "";

    modal.classList.add("abierto");
    modal.setAttribute("aria-hidden", "false");
    $("#lugarNombre").focus();
}

function cerrarFormulario() {
    modal.classList.remove("abierto");
    modal.setAttribute("aria-hidden", "true");
}

$("#btnNuevoLugar").addEventListener("click", function () { abrirFormulario(null); });

modal.addEventListener("click", function (e) {
    if (e.target === modal || e.target.closest("[data-cerrar]")) cerrarFormulario();
});
document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modal.classList.contains("abierto")) cerrarFormulario();
});

$("#formLugar").addEventListener("submit", function (e) {
    e.preventDefault();

    const id = Number($("#lugarId").value) || null;
    const nombre = $("#lugarNombre").value.trim();
    const capacidad = Number($("#lugarCapacidad").value);
    const minutos = Number($("#lugarMinutos").value);

    let error = "";
    if (!nombre) error = "Escribe el nombre del establecimiento.";
    else if (lugares.some(function (l) { return l.id !== id && l.nombre.toLowerCase() === nombre.toLowerCase(); })) error = "Ya existe un establecimiento con ese nombre.";
    else if (!(capacidad >= 1)) error = "La capacidad debe ser de al menos 1 persona.";
    else if (!(minutos > 0)) error = "Los minutos por persona deben ser mayores que 0.";

    if (error) { $("#errorForm").textContent = error; return; }

    const datos = {
        nombre: nombre,
        direccion: $("#lugarDireccion").value.trim(),
        tipo: $("#lugarTipo").value,
        horario: $("#lugarHorario").value.trim(),
        capacidad: capacidad,
        minutos: minutos
    };

    if (id) {
        const lugar = lugares.find(function (l) { return l.id === id; });
        Object.assign(lugar, datos);
        lugar.enFila = Math.min(lugar.enFila, lugar.capacidad);
        mostrarToast("Cambios guardados");
    } else {
        lugares.push(Object.assign({ id: siguienteIdLugar++, enFila: 0, activo: true }, datos));
        mostrarToast("Establecimiento creado");
    }

    cerrarFormulario();
    renderTodo();
});

/* =====================================================
   FILAS EN VIVO
===================================================== */

function renderFilas() {
    $("#filasEnVivo").innerHTML = lugares.map(function (l) {
        const c = calcular(l);
        return '<article class="tarjeta-fila' + (l.activo ? '' : ' inactiva') + '">' +
            '<header><div><h3>' + esc(l.nombre) + '</h3><small>' + esc(l.tipo) + '</small></div>' + badgeEstado(l) + '</header>' +
            '<div class="pista"><div class="relleno ' + c.nivel + '" style="width:' + (l.activo ? c.pct : 0) + '%"></div></div>' +
            '<div class="fila-cifras">' +
            '<div><strong>' + l.enFila + '</strong><span>En fila</span></div>' +
            '<div><strong>' + (l.activo ? c.pct : 0) + '%</strong><span>Ocupación</span></div>' +
            '<div><strong>' + (l.activo ? c.espera : 0) + ' min</strong><span>Espera</span></div></div>' +
            '<div class="fila-controles">' +
            '<button type="button" class="boton-secundario" data-fila="menos" data-id="' + l.id + '"' + (l.activo ? '' : ' disabled') + ' aria-label="Quitar una persona"><i class="fa-solid fa-minus"></i></button>' +
            '<button type="button" class="boton-secundario" data-fila="mas" data-id="' + l.id + '"' + (l.activo ? '' : ' disabled') + ' aria-label="Agregar una persona"><i class="fa-solid fa-plus"></i></button>' +
            '<button type="button" class="boton-secundario" data-fila="vaciar" data-id="' + l.id + '"' + (l.activo ? '' : ' disabled') + '>Vaciar</button>' +
            '</div></article>';
    }).join("");

    const ahora = new Date();
    $("#ultimaActualizacion").textContent = "Actualizado " + ahora.toLocaleTimeString("es-CO");
}

$("#filasEnVivo").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-fila]");
    if (!boton || boton.disabled) return;
    const lugar = lugares.find(function (l) { return l.id === Number(boton.dataset.id); });

    if (boton.dataset.fila === "mas") lugar.enFila = Math.min(lugar.capacidad, lugar.enFila + 1);
    if (boton.dataset.fila === "menos") lugar.enFila = Math.max(0, lugar.enFila - 1);
    if (boton.dataset.fila === "vaciar") lugar.enFila = 0;
    renderTodo();
});

$("#btnPausar").addEventListener("click", function () {
    enVivo = !enVivo;
    this.innerHTML = enVivo ? '<i class="fa-solid fa-pause"></i> Pausar' : '<i class="fa-solid fa-play"></i> Reanudar';
    $("#indicadorVivo").classList.toggle("pausado", !enVivo);
    $("#indicadorVivo").innerHTML = '<i class="fa-solid fa-circle"></i> ' + (enVivo ? "En vivo" : "Pausado");
});

/* Simulación: cada 6 segundos las filas cambian un poco */
setInterval(function () {
    if (!enVivo) return;
    activos().forEach(function (l) {
        const cambio = Math.floor(Math.random() * 5) - 2;
        l.enFila = Math.max(0, Math.min(l.capacidad, l.enFila + cambio));
    });
    renderTodo();
}, 6000);

/* =====================================================
   USUARIOS
===================================================== */

function renderUsuarios() {
    const texto = $("#buscadorUsuarios").value.toLowerCase().trim();
    const lista = usuarios.filter(function (u) {
        return !texto || (u.nombre + " " + u.correo).toLowerCase().includes(texto);
    });

    $("#tablaUsuarios").innerHTML = lista.map(function (u) {
        const esAdmin = u.tipo === "Administrador";
        const bloqueado = u.estado === "Bloqueado";
        return '<tr>' +
            '<td><div class="celda-lugar"><div class="avatar">' + esc(u.nombre.charAt(0)) + '</div>' +
            '<div><strong>' + esc(u.nombre) + '</strong><small>' + esc(u.correo) + '</small></div></div></td>' +
            '<td><span class="badge ' + (esAdmin ? "admin" : "inactivo") + '">' + u.tipo + '</span></td>' +
            '<td>' + new Date(u.registro + "T00:00:00").toLocaleDateString("es-CO", { day: "numeric", month: "short", year: "numeric" }) + '</td>' +
            '<td><span class="badge ' + (bloqueado ? "lleno" : "vacio") + '"><i class="fa-solid fa-circle"></i> ' + u.estado + '</span></td>' +
            '<td><div class="acciones"><button type="button" class="btn-icono' + (bloqueado ? '' : ' peligro') + '" data-id="' + u.id + '"' +
            (esAdmin ? ' disabled' : '') + ' aria-label="' + (bloqueado ? "Desbloquear" : "Bloquear") + ' a ' + esc(u.nombre) + '">' +
            '<i class="fa-solid ' + (bloqueado ? "fa-user-check" : "fa-user-lock") + '"></i></button></div></td></tr>';
    }).join("") || '<tr class="fila-vacia"><td colspan="5">No se encontraron usuarios.</td></tr>';
}

$("#buscadorUsuarios").addEventListener("input", renderUsuarios);

$("#tablaUsuarios").addEventListener("click", function (e) {
    const boton = e.target.closest("button[data-id]");
    if (!boton || boton.disabled) return;
    const usuario = usuarios.find(function (u) { return u.id === Number(boton.dataset.id); });
    usuario.estado = usuario.estado === "Bloqueado" ? "Activo" : "Bloqueado";
    renderUsuarios();
    renderResumen();
    mostrarToast(usuario.nombre + (usuario.estado === "Bloqueado" ? " fue bloqueado" : " fue desbloqueado"));
});

/* =====================================================
   REPORTES
===================================================== */

function renderReportes() {
    dibujarBarras("#graficaSemana", visitasSemana, " visitas");

    const lista = activos().slice().sort(function (a, b) { return calcular(b).espera - calcular(a).espera; });
    const max = Math.max.apply(null, lista.map(function (l) { return calcular(l).espera; })) || 1;
    $("#graficaEspera").innerHTML = lista.map(function (l) {
        const c = calcular(l);
        return '<div class="hbar"><span class="nombre">' + esc(l.nombre) + '</span>' +
            '<div class="pista"><div class="relleno ' + c.nivel + '" style="width:' + (c.espera / max * 100) + '%"></div></div>' +
            '<span class="valor">' + c.espera + ' min</span></div>';
    }).join("") || '<p class="suave">No hay establecimientos activos.</p>';
}

$("#btnExportar").addEventListener("click", function () {
    const filas = [["Establecimiento", "Tipo", "Activo", "En fila", "Capacidad", "Ocupación %", "Espera (min)", "Estado"]];
    lugares.forEach(function (l) {
        const c = calcular(l);
        filas.push([l.nombre, l.tipo, l.activo ? "Sí" : "No", l.enFila, l.capacidad, c.pct, c.espera, l.activo ? textoNivel[c.nivel] : "Inactivo"]);
    });

    const csv = filas.map(function (fila) {
        return fila.map(function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(",");
    }).join("\n");

    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
    const enlace = document.createElement("a");
    enlace.href = URL.createObjectURL(blob);
    enlace.download = "queuevision-reporte.csv";
    document.body.appendChild(enlace);
    enlace.click();
    enlace.remove();
    URL.revokeObjectURL(enlace.href);
    mostrarToast("Reporte exportado");
});

/* =====================================================
   CONFIGURACIÓN
===================================================== */

$("#cfgAlertas").addEventListener("change", function () {
    config.alertas = this.checked;
    renderResumen();
});

function actualizarUmbrales() {
    const moderado = Number($("#umbralModerado").value);
    const lleno = Number($("#umbralLleno").value);

    if (!(moderado >= 1) || !(lleno <= 100) || moderado >= lleno) {
        $("#mensajeUmbral").textContent = "El umbral de \"Moderado\" debe ser menor que el de \"Lleno\".";
        return;
    }
    $("#mensajeUmbral").textContent = "";
    config.moderado = moderado;
    config.lleno = lleno;
    renderTodo();
}
$("#umbralModerado").addEventListener("input", actualizarUmbrales);
$("#umbralLleno").addEventListener("input", actualizarUmbrales);

const modoOscuro = $("#modoOscuro");

function aplicarModo(oscuro) {
    document.body.classList.toggle("modo-oscuro", oscuro);
    modoOscuro.checked = oscuro;
}

let guardado = null;
try { guardado = localStorage.getItem("queuevisionAdminOscuro"); } catch (e) { /* sin almacenamiento */ }
aplicarModo(guardado === "true");

modoOscuro.addEventListener("change", function () {
    aplicarModo(modoOscuro.checked);
    try { localStorage.setItem("queuevisionAdminOscuro", String(modoOscuro.checked)); } catch (e) { /* ignorar */ }
});

/* =====================================================
   CERRAR SESIÓN
===================================================== */

$("#cerrarSesion").addEventListener("click", function () {
    if (confirm("¿Estás seguro de que deseas cerrar sesión?")) {
        // Cambia esta ruta si tu login está en otra ubicación
        window.location.href = "/HTML/login.html";
    }
});

/* =====================================================
   INICIO
===================================================== */

function renderTodo() {
    renderResumen();
    renderTablaLugares();
    renderFilas();
    renderReportes();
}

dibujarBarras("#graficaHoras", afluenciaHoras, "%");
renderUsuarios();
renderTodo();
mostrarPagina(paginaDesdeURL());