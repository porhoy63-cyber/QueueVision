const formulario =
    document.getElementById("formRecuperar");

const mensaje =
    document.getElementById("mensajeRecuperacion");


formulario.addEventListener("submit", function(event) {

    event.preventDefault();


    const dato =
        document.getElementById("datoRecuperacion")
        .value.trim();

    if (dato === "") {

        mensaje.textContent =
            "Debes ingresar tu documento o correo electrónico.";

        mensaje.className = "error";

        return;
    }

    const correoValido =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const documentoValido =
        /^[0-9]{6,}$/;


    if (
        !correoValido.test(dato) &&
        !documentoValido.test(dato)
    ) {

        mensaje.textContent =
            "Ingresa un correo válido o un documento válido.";

        mensaje.className = "error";

        return;
    }

    mensaje.textContent =
        "Solicitud válida. Se iniciará el proceso de recuperación.";

    mensaje.className = "exito";

});