/* QUEUEVISION - DASHBOARD */

const paginas = document.querySelectorAll(".pagina");
const enlacesMenu = document.querySelectorAll(".menu-item");
const tituloPagina = document.getElementById("tituloPagina");
const descripcionPagina = document.getElementById("descripcionPagina");

const informacionPaginas = {
    inicio: { titulo: "Hola, David 👋", descripcion: "Encuentra el lugar ideal sin esperar innecesariamente." },
    lugares: { titulo: "Lugares cercanos", descripcion: "Encuentra restaurantes y almacenes cerca de ti." },
    favoritos: { titulo: "Favoritos", descripcion: "Consulta los lugares que has guardado." },
    historial: { titulo: "Historial", descripcion: "Consulta los lugares que has visitado anteriormente." },
    perfil: { titulo: "Mi perfil", descripcion: "Consulta y administra la información de tu cuenta." },
    configuracion: { titulo: "Configuración", descripcion: "Personaliza tu experiencia en QueueVision." }
};

/* ---------- Mostrar página ---------- */
function mostrarPagina(nombre) {
    if (!informacionPaginas[nombre] || !document.getElementById(nombre)) {
        nombre = "inicio";
    }

    paginas.forEach(function (p) {
        p.classList.toggle("activa-pagina", p.id === nombre);
    });

    enlacesMenu.forEach(function (enlace) {
        const destino = enlace.getAttribute("href").replace("#", "");
        enlace.classList.toggle("activo", destino === nombre);
    });

    tituloPagina.textContent = informacionPaginas[nombre].titulo;
    descripcionPagina.textContent = informacionPaginas[nombre].descripcion;

    window.scrollTo({ top: 0, behavior: "smooth" });
}

function paginaDesdeURL() {
    return window.location.hash.replace("#", "") || "inicio";
}

/* ---------- Navegación: TODOS los enlaces internos (#...) ---------- */
document.querySelectorAll('a[href^="#"]').forEach(function (enlace) {
    enlace.addEventListener("click", function (event) {
        event.preventDefault();
        const destino = enlace.getAttribute("href").replace("#", "");

        if (destino !== paginaDesdeURL()) {
            history.pushState({ pagina: destino }, "", "#" + destino);
        }
        mostrarPagina(destino);
    });
});

window.addEventListener("popstate", function () {
    mostrarPagina(paginaDesdeURL());
});

mostrarPagina(paginaDesdeURL());

/* ---------- Buscador (tarjetas de Inicio y de Lugares) ---------- */
const buscador = document.getElementById("buscador");

if (buscador) {
    buscador.addEventListener("input", function () {
        const texto = buscador.value.toLowerCase().trim();

        document.querySelectorAll("#inicio .card-lugar").forEach(function (tarjeta) {
            const visible = tarjeta.textContent.toLowerCase().includes(texto);
            tarjeta.style.display = visible ? "flex" : "none";
        });
    });
}

/* ---------- Favoritos ---------- */
document.querySelectorAll(".btn-favorito").forEach(function (boton) {
    boton.addEventListener("click", function () {
        const activo = boton.classList.toggle("activo");
        const icono = boton.querySelector("i");
        icono.className = activo ? "fa-solid fa-heart" : "fa-regular fa-heart";
    });
});

/* ---------- Detalle del lugar ---------- */
const detalleLugares = {
    "Burger House": {
        tipo: "Restaurante", distancia: "0.8 km", icono: "fa-utensils", clase: "restaurante",
        ocupacion: 85, enFila: 12, espera: 15, horario: "11:00 a.m. - 10:00 p.m.",
        direccion: "Calle 45 #12-30", calificacion: "4.5",
        descripcion: "Hamburguesas artesanales con carne de res a la parrilla, papas rústicas y malteadas. Ambiente informal, ideal para ir en grupo o en familia.",
        servicios: [
            ["fa-chair", "Mesas en el local"], ["fa-bag-shopping", "Para llevar"],
            ["fa-motorcycle", "Domicilios"], ["fa-wifi", "WiFi gratis"],
            ["fa-baby", "Sillas para niños"], ["fa-credit-card", "Pago con tarjeta"]
        ],
        destacados: ["Hamburguesa doble queso", "Papas con cheddar", "Malteada de vainilla"],
        mejorHora: "Después de las 3:00 p.m. suele haber menos fila."
    },
    "Pizza Planet": {
        tipo: "Restaurante", distancia: "1.2 km", icono: "fa-pizza-slice", clase: "restaurante",
        ocupacion: 20, enFila: 2, espera: 5, horario: "12:00 m. - 11:00 p.m.",
        direccion: "Carrera 9 #50-18", calificacion: "4.7",
        descripcion: "Pizzas al horno de leña con masa de fermentación lenta, pastas y postres caseros. Espacio amplio con zona de juegos para niños.",
        servicios: [
            ["fa-chair", "Mesas en el local"], ["fa-bag-shopping", "Para llevar"],
            ["fa-motorcycle", "Domicilios"], ["fa-leaf", "Opciones vegetarianas"],
            ["fa-square-parking", "Parqueadero"], ["fa-credit-card", "Pago con tarjeta"]
        ],
        destacados: ["Pizza margarita", "Pizza pepperoni", "Lasaña de la casa"],
        mejorHora: "Ahora es buen momento: casi no hay espera."
    },
    "Éxito": {
        tipo: "Almacén de cadena", distancia: "1.5 km", icono: "fa-store", clase: "almacen",
        ocupacion: 78, enFila: 18, espera: 20, horario: "8:00 a.m. - 9:00 p.m.",
        direccion: "Avenida 68 #24-10", calificacion: "4.2",
        descripcion: "Supermercado con mercado fresco, panadería, carnes, aseo del hogar y tecnología. Cuenta con cajas rápidas y autopago.",
        servicios: [
            ["fa-cash-register", "Cajas rápidas"], ["fa-mobile-screen", "Autopago"],
            ["fa-square-parking", "Parqueadero"], ["fa-truck", "Domicilios"],
            ["fa-bread-slice", "Panadería"], ["fa-credit-card", "Pago con tarjeta"]
        ],
        destacados: ["Mercado fresco", "Panadería", "Ofertas de la semana"],
        mejorHora: "Entre semana antes de las 11:00 a.m. hay menos gente."
    }
};

function nivelOcupacion(porcentaje) {
    if (porcentaje >= 70) return { texto: "Lleno", clase: "lleno", icono: "fa-users" };
    if (porcentaje >= 35) return { texto: "Moderado", clase: "moderado", icono: "fa-user-group" };
    return { texto: "Vacío", clase: "vacio", icono: "fa-user" };
}

const modalLugar = document.getElementById("modalLugar");
const contenidoModal = document.getElementById("contenidoModal");

function abrirDetalle(nombre) {
    const d = detalleLugares[nombre];
    if (!d || !modalLugar) return;

    const nivel = nivelOcupacion(d.ocupacion);

    contenidoModal.innerHTML =
        '<div class="modal-cabecera">' +
            '<div class="icono-lugar ' + d.clase + '"><i class="fa-solid ' + d.icono + '"></i></div>' +
            '<div><h3 id="tituloModal">' + nombre + '</h3>' +
            '<p>' + d.tipo + ' · ' + d.distancia + ' · <i class="fa-solid fa-star"></i> ' + d.calificacion + '</p></div>' +
        '</div>' +

        '<div class="modal-estado ' + nivel.clase + '">' +
            '<div class="modal-estado-fila"><strong><i class="fa-solid ' + nivel.icono + '"></i> ' + nivel.texto + '</strong>' +
            '<span>' + d.ocupacion + '% de ocupación</span></div>' +
            '<div class="barra"><div class="barra-relleno" style="width:' + d.ocupacion + '%"></div></div>' +
        '</div>' +

        '<div class="modal-datos">' +
            '<div><i class="fa-solid fa-people-line"></i><strong>' + d.enFila + '</strong><span>Personas en fila</span></div>' +
            '<div><i class="fa-solid fa-clock"></i><strong>' + d.espera + ' min</strong><span>Espera estimada</span></div>' +
            '<div><i class="fa-solid fa-door-open"></i><strong>Abierto</strong><span>' + d.horario + '</span></div>' +
        '</div>' +

        '<h4>Descripción</h4><p class="modal-texto">' + d.descripcion + '</p>' +

        '<h4>Lo que ofrece</h4><ul class="modal-servicios">' +
            d.servicios.map(function (s) { return '<li><i class="fa-solid ' + s[0] + '"></i> ' + s[1] + '</li>'; }).join("") +
        '</ul>' +

        '<h4>Destacados</h4><p class="modal-texto">' + d.destacados.join(" · ") + '</p>' +

        '<h4>Dirección</h4><p class="modal-texto"><i class="fa-solid fa-location-dot"></i> ' + d.direccion + '</p>' +

        '<p class="modal-consejo"><i class="fa-solid fa-lightbulb"></i> ' + d.mejorHora + '</p>';

    modalLugar.classList.add("abierto");
    modalLugar.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
}

function cerrarDetalle() {
    modalLugar.classList.remove("abierto");
    modalLugar.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
}

/* Clic en una tarjeta (Inicio y Lugares) o en el botón "Ver" */
document.querySelectorAll(".card-lugar, .lugar-card").forEach(function (tarjeta) {
    tarjeta.style.cursor = "pointer";

    tarjeta.addEventListener("click", function (event) {
        if (event.target.closest(".btn-favorito")) return;
        abrirDetalle(tarjeta.querySelector("h3").textContent.trim());
    });
});

if (modalLugar) {
    modalLugar.addEventListener("click", function (event) {
        if (event.target === modalLugar || event.target.closest("[data-cerrar]")) {
            cerrarDetalle();
        }
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape" && modalLugar.classList.contains("abierto")) {
            cerrarDetalle();
        }
    });
}

/* ---------- Cerrar sesión ---------- */
const botonCerrarSesion = document.getElementById("cerrarSesion");

if (botonCerrarSesion) {
    botonCerrarSesion.addEventListener("click", function () {
        if (confirm("¿Estás seguro de que deseas cerrar sesión?")) {
            // Cambia esta ruta si tu login está en otra ubicación
            window.location.href = "/HTML/login.html";
        }
    });
}

/* ---------- Modo oscuro ---------- */
const modoOscuro = document.getElementById("modoOscuro");

if (modoOscuro) {
    function aplicarModo(oscuro) {
        document.body.classList.toggle("modo-oscuro", oscuro);
        modoOscuro.checked = oscuro;
    }

    let guardado = null;
    try {
        guardado = localStorage.getItem("queuevisionModoOscuro");
    } catch (e) { /* almacenamiento no disponible */ }

    aplicarModo(guardado === "true");

    modoOscuro.addEventListener("change", function () {
        aplicarModo(modoOscuro.checked);
        try {
            localStorage.setItem("queuevisionModoOscuro", String(modoOscuro.checked));
        } catch (e) { /* ignorar */ }
    });
}